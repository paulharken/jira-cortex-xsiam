"""
Cortex XSIAM -> Jira Cloud Sync Integration

Single-file XSIAM automation that syncs Cortex cases and standalone issues
to Atlassian Jira Cloud. Runs as a cron job every 60 seconds.

State is persisted via demisto integration context (JSON blob).
Only dependency is `requests` (pre-installed in XSIAM runtime).

Forked from jira-cortex (Docker microservice). Stripped to core sync logic.
"""

import base64
import json
import time
import traceback
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

import requests

import demistomock as demisto
from CommonServerPython import *  # noqa: F401,F403

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Section 1: Config
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SEVERITY_TO_PRIORITY = {
    "INFORMATIONAL": "Lowest",
    "LOW": "Low",
    "MEDIUM": "Medium",
    "HIGH": "High",
    "CRITICAL": "Highest",
    # Cortex cases return lowercase severity
    "informational": "Lowest",
    "low": "Low",
    "medium": "Medium",
    "high": "High",
    "critical": "Highest",
}

MAX_RETRY_ATTEMPTS = 5
CLOSED_RECORD_TTL_DAYS = 7
PAGE_SIZE = 100


@dataclass
class Config:
    cortex_base_url: str
    cortex_api_key: str
    cortex_api_key_id: str
    cortex_console_url: str
    cortex_case_domain: str
    jira_site_url: str
    jira_cloud_id: str
    jira_email: str
    jira_api_token: str
    jira_project_key: str
    jira_issue_type: str
    jira_case_id_field: str
    jira_issue_id_field: str
    jira_xdr_url_field: str
    resolution_type_map: str
    default_resolution_type: str
    max_sync_cases: int
    sync_issues: bool
    sync_from_date: str

    @classmethod
    def from_params(cls) -> "Config":
        params = demisto.params()
        return cls(
            cortex_base_url=params.get("cortex_base_url", "").rstrip("/"),
            cortex_api_key=params.get("cortex_api_key", {}).get("password", "") if isinstance(params.get("cortex_api_key"), dict) else params.get("cortex_api_key", ""),
            cortex_api_key_id=str(params.get("cortex_api_key_id", "")),
            cortex_console_url=params.get("cortex_console_url", "").rstrip("/"),
            cortex_case_domain=params.get("cortex_case_domain", "security"),
            jira_site_url=params.get("jira_site_url", "").rstrip("/"),
            jira_cloud_id=params.get("jira_cloud_id", ""),
            jira_email=params.get("jira_email", ""),
            jira_api_token=params.get("jira_api_token", {}).get("password", "") if isinstance(params.get("jira_api_token"), dict) else params.get("jira_api_token", ""),
            jira_project_key=params.get("jira_project_key", ""),
            jira_issue_type=params.get("jira_issue_type", "Alert"),
            jira_case_id_field=params.get("jira_case_id_field", ""),
            jira_issue_id_field=params.get("jira_issue_id_field", ""),
            jira_xdr_url_field=params.get("jira_xdr_url_field", ""),
            resolution_type_map=params.get("resolution_type_map", '{"False Positive": "Resolved - False Positive", "Duplicate": "Resolved - Duplicate Case", "Known Issue": "Resolved - Known Issue", "Security Testing": "Resolved - Security Testing", "TP Malicious": "Resolved - TP Malicious", "TP Benign": "Resolved - TP Benign", "SPAM": "Resolved - SPAM or Marketing"}'),
            default_resolution_type=params.get("default_resolution_type", "Resolved - Other"),
            max_sync_cases=int(params.get("max_sync_cases", "0")),
            sync_issues=params.get("sync_issues", False),
            sync_from_date=params.get("sync_from_date", ""),
        )

    def validate(self) -> list[str]:
        errors = []
        # Cortex API creds only required when running locally (not in XSIAM)
        if not _is_xsiam_runtime():
            for name, value in {
                "cortex_base_url": self.cortex_base_url,
                "cortex_api_key": self.cortex_api_key,
                "cortex_api_key_id": self.cortex_api_key_id,
            }.items():
                if not value or not value.strip():
                    errors.append(f"Missing required parameter: {name}")
        required = {
            "jira_email": self.jira_email,
            "jira_api_token": self.jira_api_token,
            "jira_project_key": self.jira_project_key,
        }
        for name, value in required.items():
            if not value or not value.strip():
                errors.append(f"Missing required parameter: {name}")
        if not self.jira_cloud_id.strip() and not self.jira_site_url.strip():
            errors.append("Either jira_cloud_id or jira_site_url must be set")
        return errors


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Section 2: State Layer
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def get_state() -> dict:
    """Load persistent state from integration context."""
    ctx = demisto.getIntegrationContext() or {}
    # Ensure all expected keys exist
    ctx.setdefault("last_poll_ms", 0)
    ctx.setdefault("last_jira_poll_iso", "")
    ctx.setdefault("sync_records", {})
    ctx.setdefault("issue_sync_records", {})
    ctx.setdefault("retry_queue", [])
    ctx.setdefault("user_cache", {})
    return ctx


def save_state(state: dict) -> None:
    """Persist state to integration context."""
    demisto.setIntegrationContext(state)


def prune_closed_records(state: dict) -> int:
    """Remove closed records older than CLOSED_RECORD_TTL_DAYS. Returns count pruned."""
    cutoff = datetime.now(timezone.utc) - timedelta(days=CLOSED_RECORD_TTL_DAYS)
    cutoff_iso = cutoff.isoformat()
    pruned = 0

    for records_key in ("sync_records", "issue_sync_records"):
        to_delete = []
        for record_id, record in state[records_key].items():
            if record.get("status") == "closed":
                closed_at = record.get("closed_at", record.get("created_at", ""))
                if closed_at and closed_at < cutoff_iso:
                    to_delete.append(record_id)
        for record_id in to_delete:
            del state[records_key][record_id]
            pruned += 1

    return pruned


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Section 3: Jira Client
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class JiraClient:
    def __init__(self, config: Config):
        if config.jira_cloud_id:
            self.base_url = f"https://api.atlassian.com/ex/jira/{config.jira_cloud_id}"
        else:
            self.base_url = config.jira_site_url
            demisto.info(f"No Jira Cloud ID — using site URL: {self.base_url}")
        self.project_key = config.jira_project_key
        self.issue_type = config.jira_issue_type
        token = base64.b64encode(
            f"{config.jira_email}:{config.jira_api_token}".encode()
        ).decode()
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Basic {token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        })
        self.session.timeout = 30

    def _request(self, method: str, url: str, **kwargs) -> requests.Response:
        """HTTP request with retry on 429/503."""
        delay = 1.0
        for attempt in range(4):
            resp = self.session.request(method, url, timeout=30, **kwargs)
            if resp.status_code not in (429, 503):
                return resp
            demisto.info(f"Jira HTTP {resp.status_code} on attempt {attempt + 1}/4, retrying in {delay:.0f}s")
            time.sleep(delay)
            delay *= 2
        return resp

    def create_issue(
        self, summary: str, description_adf: dict, severity: str,
        extra_fields: Optional[dict] = None,
    ) -> str:
        priority = SEVERITY_TO_PRIORITY.get(severity, "Medium")
        body = {
            "fields": {
                "project": {"key": self.project_key},
                "summary": summary[:255],
                "description": description_adf,
                "issuetype": {"name": self.issue_type},
                "priority": {"name": priority},
            }
        }
        if extra_fields:
            body["fields"].update(extra_fields)
        url = f"{self.base_url}/rest/api/3/issue"
        demisto.info(f"Creating Jira issue: project={self.project_key} priority={priority}")
        resp = self._request("POST", url, json=body)
        resp.raise_for_status()
        key = resp.json()["key"]
        demisto.info(f"Created Jira issue {key}")
        return key

    def update_priority(self, issue_key: str, severity: str) -> None:
        priority = SEVERITY_TO_PRIORITY.get(severity, "Medium")
        body = {"fields": {"priority": {"name": priority}}}
        url = f"{self.base_url}/rest/api/3/issue/{issue_key}"
        resp = self._request("PUT", url, json=body)
        resp.raise_for_status()
        demisto.info(f"Updated {issue_key} priority to {priority}")

    def add_comment(self, issue_key: str, body_text: str) -> None:
        body = {
            "body": {
                "version": 1,
                "type": "doc",
                "content": [
                    {"type": "paragraph", "content": [{"type": "text", "text": body_text}]}
                ],
            }
        }
        url = f"{self.base_url}/rest/api/3/issue/{issue_key}/comment"
        resp = self._request("POST", url, json=body)
        resp.raise_for_status()
        demisto.debug(f"Added comment to {issue_key}")

    def search_closed_alerts(self, updated_since: str) -> list[dict]:
        jql = (
            f'project = "{self.project_key}" '
            f'AND issuetype = "{self.issue_type}" '
            f'AND status changed to "Closed" AFTER "{updated_since}"'
        )
        url = f"{self.base_url}/rest/api/3/search/jql"
        body = {"jql": jql, "fields": ["key", "status", "updated"]}
        resp = self._request("POST", url, json=body)
        resp.raise_for_status()
        issues = resp.json().get("issues", [])
        demisto.info(f"Found {len(issues)} closed Jira alerts since {updated_since}")
        return issues

    def get_issue_detail(self, issue_key: str) -> dict:
        url = f"{self.base_url}/rest/api/3/issue/{issue_key}?fields=summary,status,created"
        resp = self._request("GET", url)
        resp.raise_for_status()
        data = resp.json()
        fields = data.get("fields", {})
        status_obj = fields.get("status") or {}
        return {
            "summary": fields.get("summary", ""),
            "status": status_obj.get("name", ""),
            "status_category": (status_obj.get("statusCategory") or {}).get("key", ""),
            "created": fields.get("created", ""),
        }

    def get_changelog(self, issue_key: str) -> list[dict]:
        transitions: list[dict] = []
        start_at = 0
        while True:
            url = (
                f"{self.base_url}/rest/api/3/issue/{issue_key}/changelog"
                f"?startAt={start_at}&maxResults=100"
            )
            resp = self._request("GET", url)
            resp.raise_for_status()
            data = resp.json()
            for history in data.get("values", []):
                author = history.get("author", {})
                created = history.get("created", "")
                for item in history.get("items", []):
                    if item.get("field") == "status":
                        transitions.append({
                            "author_id": author.get("accountId", ""),
                            "author_name": author.get("displayName", "Unknown"),
                            "created": created,
                            "from_status": item.get("fromString", ""),
                            "to_status": item.get("toString", ""),
                        })
            total = data.get("total", 0)
            start_at += len(data.get("values", []))
            if start_at >= total:
                break
        return transitions

    def find_ticket_by_field(self, field_id: str, value: str) -> Optional[str]:
        # JQL requires cf[NNNNN] syntax for custom fields, not "customfield_NNNNN"
        if field_id.startswith("customfield_"):
            cf_num = field_id.replace("customfield_", "")
            jql_field = f"cf[{cf_num}]"
        else:
            jql_field = f'"{field_id}"'
        jql = f'project = "{self.project_key}" AND {jql_field} = "{value}"'
        url = f"{self.base_url}/rest/api/3/search/jql"
        body = {"jql": jql, "fields": ["key"], "maxResults": 1}
        resp = self._request("POST", url, json=body)
        resp.raise_for_status()
        issues = resp.json().get("issues", [])
        if issues:
            key = issues[0]["key"]
            demisto.info(f"Duplicate check: found {key} for {field_id}={value}")
            return key
        return None

    def link_issues(self, inward_key: str, outward_key: str) -> None:
        body = {
            "type": {"name": "Relates"},
            "inwardIssue": {"key": inward_key},
            "outwardIssue": {"key": outward_key},
        }
        url = f"{self.base_url}/rest/api/3/issueLink"
        resp = self._request("POST", url, json=body)
        resp.raise_for_status()
        demisto.debug(f"Linked {inward_key} -> {outward_key}")

    def search_user(self, email: str) -> Optional[str]:
        """Search for a Jira user by email. Returns accountId or None."""
        url = f"{self.base_url}/rest/api/3/user/search?query={email}&maxResults=10"
        resp = self._request("GET", url)
        resp.raise_for_status()
        for user in resp.json():
            if user.get("accountType") == "atlassian" and user.get("active", False):
                return user.get("accountId", "")
        return None

    def assign_issue(self, issue_key: str, account_id: str) -> None:
        url = f"{self.base_url}/rest/api/3/issue/{issue_key}/assignee"
        resp = self._request("PUT", url, json={"accountId": account_id})
        resp.raise_for_status()
        demisto.debug(f"Assigned {issue_key} to {account_id}")

    def get_project_statuses(self) -> list[str]:
        """Get all workflow status names for the configured project and issue type."""
        url = f"{self.base_url}/rest/api/3/project/{self.project_key}/statuses"
        resp = self._request("GET", url)
        resp.raise_for_status()
        statuses: set[str] = set()
        for issuetype in resp.json():
            if issuetype.get("name", "").lower() == self.issue_type.lower():
                for status in issuetype.get("statuses", []):
                    statuses.add(status["name"])
        # If no match on issue type, return all statuses across all types
        if not statuses:
            for issuetype in resp.json():
                for status in issuetype.get("statuses", []):
                    statuses.add(status["name"])
        return sorted(statuses)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Section 4: Cortex Client
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


def _is_xsiam_runtime() -> bool:
    """Detect if we're running inside XSIAM (vs local via run_local.py)."""
    try:
        # demisto.callingContext exists in real XSIAM runtime, not in mock
        ctx = demisto.callingContext
        return ctx is not None
    except (AttributeError, Exception):
        return False


class CortexClient:
    def __init__(self, config: Config):
        self.use_native = _is_xsiam_runtime()
        # Public API fallback for local testing only
        if not self.use_native:
            self.base_url = config.cortex_base_url
            self.session = requests.Session()
            self.session.headers.update({
                "Authorization": config.cortex_api_key,
                "x-xdr-auth-id": config.cortex_api_key_id,
                "Content-Type": "application/json",
                "Accept": "application/json",
            })
        demisto.info(f"CortexClient mode: {'native (internalHttpRequest)' if self.use_native else 'public API'}")

    def _native_post(self, uri: str, body: dict) -> dict:
        """Call Cortex API via demisto.internalHttpRequest (available in integrations from server 6.1+)."""
        resp = demisto.internalHttpRequest("POST", uri, json.dumps(body))
        status_code = resp.get("statusCode", 0)
        if status_code >= 400:
            raise RuntimeError(f"internalHttpRequest POST {uri} returned {status_code}: {resp.get('body', '')}")
        resp_body = resp.get("body", "")
        if not resp_body:
            return {}
        return json.loads(resp_body)

    def _native_get(self, uri: str) -> dict:
        """Call Cortex API via demisto.internalHttpRequest (available in integrations from server 6.1+)."""
        resp = demisto.internalHttpRequest("GET", uri)
        status_code = resp.get("statusCode", 0)
        if status_code >= 400:
            raise RuntimeError(f"internalHttpRequest GET {uri} returned {status_code}: {resp.get('body', '')}")
        resp_body = resp.get("body", "")
        if not resp_body:
            return {}
        return json.loads(resp_body)

    def _fallback_request(self, method: str, url: str, **kwargs) -> requests.Response:
        """HTTP request with retry on 429/503. Used for local testing only."""
        delay = 1.0
        for attempt in range(4):
            resp = self.session.request(method, url, timeout=30, **kwargs)
            if resp.status_code not in (429, 503):
                return resp
            demisto.info(f"Cortex HTTP {resp.status_code} on attempt {attempt + 1}/4, retrying in {delay:.0f}s")
            time.sleep(delay)
            delay *= 2
        return resp

    def search_cases(self, filters: Optional[list[dict]] = None) -> list[dict]:
        all_cases: list[dict] = []
        search_from = 0

        while True:
            body = {
                "request_data": {
                    "filters": filters or [],
                    "search_from": search_from,
                    "search_to": search_from + PAGE_SIZE,
                    "sort": {"field": "creation_time", "keyword": "asc"},
                }
            }

            if self.use_native:
                data = self._native_post("/public_api/v1/case/search", body)
            else:
                resp = self._fallback_request("POST", f"{self.base_url}/public_api/v1/case/search", json=body)
                resp.raise_for_status()
                data = resp.json()

            cases = data.get("reply", {}).get("DATA", [])
            all_cases.extend(cases)
            total = data.get("reply", {}).get("TOTAL_COUNT", 0)
            filter_count = data.get("reply", {}).get("FILTER_COUNT", total)
            effective_total = min(total, filter_count) if filter_count else total
            search_from += PAGE_SIZE
            if not cases or search_from >= effective_total:
                break

        demisto.info(f"Cortex: fetched {len(all_cases)} cases")
        return all_cases

    def update_case(self, case_id: int, status: str, reason: str, comment: str = "") -> None:
        body = {
            "request_data": {
                "update_data": {
                    "status_progress": status,
                    "resolve_reason": reason,
                    "resolve_comment": comment,
                }
            }
        }

        if self.use_native:
            self._native_post(f"/public_api/v1/case/update/{case_id}", body)
        else:
            resp = self._fallback_request("POST", f"{self.base_url}/public_api/v1/case/update/{case_id}", json=body)
            resp.raise_for_status()
        # 204 No Content on success — do NOT call .json()
        demisto.info(f"Cortex case {case_id} updated: status={status} reason={reason}")

    def get_playbook_state(self, issue_id) -> Optional[str]:
        """Get playbook execution state for an issue/investigation.

        Returns the playbook state string (e.g. 'completed', 'inprogress', 'error')
        or None if the playbook data couldn't be retrieved.
        """
        try:
            if self.use_native:
                data = self._native_get(f"/xsoar/inv-playbook/{issue_id}")
                return data.get("state")
            else:
                resp = self._fallback_request("GET", f"{self.base_url}/xsoar/inv-playbook/{issue_id}")
                if not resp.ok:
                    demisto.debug(f"Playbook check for issue {issue_id}: HTTP {resp.status_code}")
                    return None
                return resp.json().get("state")
        except Exception:
            demisto.debug(f"Playbook check failed for issue {issue_id}: {traceback.format_exc()}")
            return None

    def case_playbooks_ready(self, issue_ids: list) -> bool:
        """Check if all playbooks for a case's issues have completed.

        Returns True if every issue's playbook state is 'completed',
        False if any are still running or couldn't be checked.
        """
        if not issue_ids:
            return True
        for issue_id in issue_ids:
            state = self.get_playbook_state(issue_id)
            if state != "completed":
                demisto.debug(f"Issue {issue_id} playbook not ready: state={state}")
                return False
        return True

    def search_issues_filtered(self, filters: Optional[list[dict]] = None) -> list[dict]:
        all_issues: list[dict] = []
        search_from = 0

        while True:
            body = {
                "request_data": {
                    "filters": filters or [],
                    "search_from": search_from,
                    "search_to": search_from + PAGE_SIZE,
                }
            }

            if self.use_native:
                data = self._native_post("/public_api/v1/issue/search", body)
            else:
                resp = self._fallback_request("POST", f"{self.base_url}/public_api/v1/issue/search", json=body)
                resp.raise_for_status()
                data = resp.json()

            issues = data.get("reply", {}).get("DATA", [])
            all_issues.extend(issues)
            total = data.get("reply", {}).get("TOTAL_COUNT", 0)
            filter_count = data.get("reply", {}).get("FILTER_COUNT", total)
            effective_total = min(total, filter_count) if filter_count else total
            search_from += PAGE_SIZE
            if not issues or search_from >= effective_total:
                break

        demisto.info(f"Cortex: fetched {len(all_issues)} issues")
        return all_issues


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Section 5: ADF Builder
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def _adf_text(text: str, bold: bool = False) -> dict:
    node: dict = {"type": "text", "text": text}
    if bold:
        node["marks"] = [{"type": "strong"}]
    return node


def _adf_paragraph(*inlines: dict) -> dict:
    return {"type": "paragraph", "content": list(inlines)}


def _adf_heading(text: str, level: int = 3) -> dict:
    return {
        "type": "heading",
        "attrs": {"level": level},
        "content": [_adf_text(text)],
    }


def _adf_link(text: str, href: str) -> dict:
    return {
        "type": "text",
        "text": text,
        "marks": [{"type": "link", "attrs": {"href": href}}],
    }


def _adf_rule() -> dict:
    return {"type": "rule"}


def _adf_table_row(*cells: dict) -> dict:
    return {"type": "tableRow", "content": list(cells)}


def _adf_table_header(text: str) -> dict:
    return {
        "type": "tableHeader",
        "content": [_adf_paragraph(_adf_text(text, bold=True))],
    }


def _adf_table_cell(text: str) -> dict:
    return {
        "type": "tableCell",
        "content": [_adf_paragraph(_adf_text(text))],
    }


def _adf_table_cell_link(text: str, href: str) -> dict:
    return {
        "type": "tableCell",
        "content": [_adf_paragraph(_adf_link(text, href))],
    }


def _format_creation_time(raw: object) -> str:
    if isinstance(raw, (int, float)):
        try:
            return datetime.fromtimestamp(raw / 1000, tz=timezone.utc).strftime(
                "%Y-%m-%d %H:%M:%S UTC"
            )
        except (OSError, ValueError):
            return str(raw)
    return str(raw) if raw else "N/A"


def build_case_description_adf(case: dict, config: Config) -> dict:
    """Build a rich ADF document for the Jira ticket description (case)."""
    case_id = case.get("case_id", "?")
    content: list[dict] = []

    # Cortex deep link
    console_url = config.cortex_console_url
    if console_url:
        case_url = f"{console_url}/case-management/case/{case_id}"
        content.append(
            _adf_paragraph(
                _adf_text("Open in Cortex: ", bold=True),
                _adf_link(case_url, case_url),
            )
        )
        content.append(_adf_rule())

    # Case details table
    created = _format_creation_time(case.get("creation_time"))
    severity = case.get("severity", "N/A")
    status = case.get("status_progress", "N/A")
    domain = case.get("case_domain", "N/A")
    owner = case.get("owner", "N/A")
    assigned = case.get("assigned_user_pretty_name", case.get("assigned_user_mail", "Unassigned"))
    score = case.get("aggregated_score")

    content.append(_adf_heading("Case Details"))
    header_row = _adf_table_row(
        _adf_table_header("Field"),
        _adf_table_header("Value"),
    )
    rows = [
        header_row,
        _adf_table_row(_adf_table_cell("Case ID"), _adf_table_cell(str(case_id))),
        _adf_table_row(_adf_table_cell("Domain"), _adf_table_cell(str(domain))),
        _adf_table_row(_adf_table_cell("Severity"), _adf_table_cell(str(severity))),
        _adf_table_row(_adf_table_cell("Status"), _adf_table_cell(str(status))),
        _adf_table_row(_adf_table_cell("Created"), _adf_table_cell(created)),
        _adf_table_row(_adf_table_cell("Owner"), _adf_table_cell(str(owner))),
        _adf_table_row(_adf_table_cell("Assigned To"), _adf_table_cell(str(assigned))),
    ]
    if score is not None:
        rows.append(_adf_table_row(_adf_table_cell("Score"), _adf_table_cell(str(score))))
    content.append({"type": "table", "content": rows})

    # Description
    desc = case.get("description", "No description")
    if desc:
        content.append(_adf_heading("Description"))
        content.append(_adf_paragraph(_adf_text(desc)))

    # Assets
    assets = case.get("assets", [])
    if assets:
        content.append(_adf_heading("Affected Assets"))
        asset_items = []
        for asset in assets:
            if isinstance(asset, dict):
                name = asset.get("name", asset.get("host_name", str(asset)))
                asset_type = asset.get("type", "")
                label = f"{name} ({asset_type})" if asset_type else name
            else:
                label = str(asset)
            asset_items.append({
                "type": "listItem",
                "content": [_adf_paragraph(_adf_text(label))],
            })
        content.append({"type": "bulletList", "content": asset_items})

    # Linked issues
    issues = case.get("issue_ids", case.get("issues", []))
    if issues:
        content.append(_adf_heading("Linked Cortex Issues"))
        if console_url:
            inlines: list[dict] = []
            for idx, issue_id in enumerate(issues):
                if idx > 0:
                    inlines.append(_adf_text(", "))
                issue_url = f"{console_url}/alerts-and-incidents/alerts/{issue_id}"
                inlines.append(_adf_link(str(issue_id), issue_url))
            content.append(_adf_paragraph(*inlines))
        else:
            content.append(
                _adf_paragraph(_adf_text(", ".join(str(i) for i in issues)))
            )

    return {"version": 1, "type": "doc", "content": content}


def build_issue_description_adf(issue: dict, config: Config) -> dict:
    """Build a rich ADF document for the Jira ticket description (standalone issue)."""
    issue_id = issue.get("id", "?")
    content: list[dict] = []

    # Cortex deep link
    console_url = config.cortex_console_url
    if console_url:
        issue_url = f"{console_url}/alerts-and-incidents/alerts/{issue_id}"
        content.append(
            _adf_paragraph(
                _adf_text("Open in Cortex: ", bold=True),
                _adf_link(issue_url, issue_url),
            )
        )
        content.append(_adf_rule())

    # Issue details table
    created = _format_creation_time(issue.get("observation_time"))
    severity = issue.get("severity", "N/A")
    status = issue.get("status", {})
    status_progress = status.get("progress", "N/A") if isinstance(status, dict) else str(status)
    domain = issue.get("issue_domain", "N/A")
    assigned = issue.get("assigned_to_pretty", issue.get("assigned_to", "Unassigned"))
    detection = issue.get("detection", {})
    detection_method = detection.get("method", "N/A") if isinstance(detection, dict) else "N/A"

    content.append(_adf_heading("Issue Details"))
    header_row = _adf_table_row(
        _adf_table_header("Field"),
        _adf_table_header("Value"),
    )
    rows = [
        header_row,
        _adf_table_row(_adf_table_cell("Issue ID"), _adf_table_cell(str(issue_id))),
        _adf_table_row(_adf_table_cell("Domain"), _adf_table_cell(str(domain))),
        _adf_table_row(_adf_table_cell("Severity"), _adf_table_cell(str(severity))),
        _adf_table_row(_adf_table_cell("Status"), _adf_table_cell(str(status_progress))),
        _adf_table_row(_adf_table_cell("Observed"), _adf_table_cell(created)),
        _adf_table_row(_adf_table_cell("Assigned To"), _adf_table_cell(str(assigned))),
        _adf_table_row(_adf_table_cell("Detection"), _adf_table_cell(str(detection_method))),
    ]
    content.append({"type": "table", "content": rows})

    # Description / name
    name = issue.get("name", issue.get("description", "No description"))
    if name:
        content.append(_adf_heading("Description"))
        content.append(_adf_paragraph(_adf_text(str(name))))

    # Assets
    assets = issue.get("assets", [])
    if assets:
        content.append(_adf_heading("Affected Assets"))
        asset_items = []
        for asset in assets:
            if isinstance(asset, dict):
                asset_name = asset.get("name", asset.get("host_name", str(asset)))
                asset_type = asset.get("type", "")
                label = f"{asset_name} ({asset_type})" if asset_type else asset_name
            else:
                label = str(asset)
            asset_items.append({
                "type": "listItem",
                "content": [_adf_paragraph(_adf_text(label))],
            })
        content.append({"type": "bulletList", "content": asset_items})

    return {"version": 1, "type": "doc", "content": content}


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Section 6: Analyst Assignment Helper
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def resolve_and_assign(
    jira: JiraClient, state: dict, issue_key: str, email: str,
) -> None:
    """Resolve a Cortex analyst email to a Jira account and assign the ticket."""
    if not email:
        return

    # Check cache first
    account_id = state["user_cache"].get(email)

    if not account_id:
        try:
            account_id = jira.search_user(email)
            if account_id:
                state["user_cache"][email] = account_id
                demisto.info(f"Cached Jira user: {email} -> {account_id}")
            else:
                demisto.info(f"No Jira user found for {email}")
                return
        except Exception:
            demisto.error(f"Failed to look up Jira user for {email}: {traceback.format_exc()}")
            return

    try:
        jira.assign_issue(issue_key, account_id)
    except Exception:
        demisto.error(f"Failed to assign {issue_key} to {account_id} ({email}): {traceback.format_exc()}")


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Section 7: Cortex -> Jira Sync
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def sync_cortex_to_jira(
    cortex: CortexClient, jira: JiraClient, state: dict, config: Config,
) -> dict:
    """Fetch new/changed Cortex cases and create Jira tickets. Returns stats."""
    stats = {"created": 0, "existing": 0, "failed": 0, "retried": 0, "pending_playbook": 0}

    # Process retry queue first
    stats["retried"] = _process_retry_queue(cortex, jira, state, config)

    # Build filters
    last_poll_ms = state["last_poll_ms"]
    now = datetime.now(timezone.utc)
    now_ms = int(now.timestamp() * 1000)

    if last_poll_ms == 0:
        demisto.info("Cortex->Jira: FIRST RUN — fetching all non-resolved cases")
        filters = [
            {"field": "status_progress", "operator": "nin", "value": ["Resolved"]},
        ]
        if config.sync_from_date:
            from_ms = int(datetime.fromisoformat(config.sync_from_date).timestamp() * 1000)
            filters.append({"field": "last_update_time", "operator": "gte", "value": from_ms})
            demisto.info(f"Cortex->Jira: applying sync_from_date floor {config.sync_from_date}")
    else:
        since_ms = last_poll_ms - 60000  # 60s lookback buffer
        filters = [
            {"field": "last_update_time", "operator": "gte", "value": since_ms},
            {"field": "status_progress", "operator": "nin", "value": ["Resolved"]},
        ]
        demisto.info(f"Cortex->Jira: fetching cases updated since {since_ms}")

    cases = cortex.search_cases(filters=filters)
    domain = config.cortex_case_domain.lower()
    max_cases = config.max_sync_cases

    for case in cases:
        case_id = str(case.get("case_id", ""))
        case_domain = case.get("case_domain", "")
        case_status = case.get("status_progress", "")

        if case_domain.lower() != domain:
            continue
        if case_status.lower() == "resolved":
            continue
        if max_cases > 0 and stats["created"] >= max_cases:
            break

        # Skip cases whose playbooks haven't finished yet
        issue_ids = [str(i) for i in case.get("issue_ids", case.get("issues", []))]
        if not cortex.case_playbooks_ready(issue_ids):
            demisto.info(f"Case {case_id}: playbooks not yet completed — deferring to next cycle")
            stats["pending_playbook"] += 1
            continue

        result = _handle_case(case, cortex, jira, state, config)
        if result == "created":
            stats["created"] += 1
        elif result == "existing":
            stats["existing"] += 1
        else:
            stats["failed"] += 1
            # Enqueue for retry
            _enqueue_retry(state, case_id, case)

    # Update poll timestamp
    state["last_poll_ms"] = now_ms

    demisto.info(
        f"Cortex->Jira: {stats['created']} created, {stats['existing']} existing, "
        f"{stats['failed']} failed, {stats['retried']} retried, "
        f"{stats['pending_playbook']} awaiting playbooks"
    )
    return stats


def _handle_case(
    case: dict, cortex: CortexClient, jira: JiraClient, state: dict, config: Config,
) -> str:
    """Handle a single case. Returns 'created', 'existing', or 'failed'."""
    case_id = str(case["case_id"])
    description = case.get("description", "No description")
    severity = case.get("severity", "MEDIUM")
    issue_ids = [str(i) for i in case.get("issue_ids", case.get("issues", []))]

    # Already synced and open?
    existing = state["sync_records"].get(case_id)
    if existing and existing["status"] == "open":
        _sync_severity_change(existing, severity, jira)
        _sync_new_issues(existing, issue_ids, cortex, jira, state, config)
        return "existing"

    # Previously closed? (reopen scenario)
    closed_jira_key = None
    if existing and existing["status"] == "closed":
        closed_jira_key = existing["jira_key"]

    # Build ticket fields
    summary = f"[CORTEX-{case_id}] {description.replace(chr(10), ' ').replace(chr(13), ' ').strip()}"
    description_adf = build_case_description_adf(case, config)
    extra_fields: dict = {}
    if config.jira_case_id_field:
        extra_fields[config.jira_case_id_field] = str(case_id)
    if config.jira_xdr_url_field and config.cortex_console_url:
        xdr_url = f"{config.cortex_console_url}/case-management/case/{case_id}"
        extra_fields[config.jira_xdr_url_field] = xdr_url

    # Duplicate detection
    if config.jira_case_id_field:
        try:
            existing_key = jira.find_ticket_by_field(config.jira_case_id_field, str(case_id))
            if existing_key:
                demisto.info(f"Duplicate detected: case {case_id} already has {existing_key}")
                state["sync_records"][case_id] = {
                    "jira_key": existing_key,
                    "severity": severity.upper(),
                    "issue_ids": issue_ids,
                    "status": "open",
                    "created_at": datetime.now(timezone.utc).isoformat(),
                }
                return "created"
        except Exception:
            demisto.info(f"Duplicate check failed for case {case_id} — proceeding with creation")

    # Create Jira ticket
    try:
        jira_key = jira.create_issue(summary, description_adf, severity, extra_fields or None)
    except Exception:
        demisto.error(f"Failed to create Jira issue for case {case_id}: {traceback.format_exc()}")
        return "failed"

    # Link to previous ticket if reopened
    if closed_jira_key:
        try:
            jira.link_issues(jira_key, closed_jira_key)
            demisto.info(f"Case {case_id} reopened: linked {jira_key} to {closed_jira_key}")
        except Exception:
            demisto.error(f"Failed to link {jira_key} to {closed_jira_key}")

    # Auto-assign if Cortex case has an assigned analyst
    assigned_email = case.get("assigned_user_mail", "")
    if assigned_email:
        resolve_and_assign(jira, state, jira_key, assigned_email)

    # Record in state
    state["sync_records"][case_id] = {
        "jira_key": jira_key,
        "severity": severity.upper(),
        "issue_ids": issue_ids,
        "status": "open",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }

    demisto.info(f"Synced case {case_id} -> {jira_key}")
    return "created"


def _sync_severity_change(record: dict, current_severity: str, jira: JiraClient) -> None:
    stored = record.get("severity", "MEDIUM")
    if current_severity.upper() == stored.upper():
        return
    try:
        jira.update_priority(record["jira_key"], current_severity)
        record["severity"] = current_severity.upper()
        demisto.info(f"Severity updated {record['jira_key']}: {stored} -> {current_severity}")
    except Exception:
        demisto.error(f"Failed to update priority on {record['jira_key']}: {traceback.format_exc()}")


def _sync_new_issues(
    record: dict, current_issue_ids: list[str],
    cortex: CortexClient, jira: JiraClient, state: dict, config: Config,
) -> None:
    known_ids = set(record.get("issue_ids", []))
    current_ids = {str(i) for i in current_issue_ids}
    new_ids = current_ids - known_ids

    if not new_ids:
        return

    console_url = config.cortex_console_url
    for issue_id in new_ids:
        if console_url:
            issue_url = f"{console_url}/alerts-and-incidents/alerts/{issue_id}"
            comment = f"New issue added: #{issue_id} — {issue_url}"
        else:
            comment = f"New issue added: #{issue_id}"
        try:
            jira.add_comment(record["jira_key"], comment)
        except Exception:
            demisto.error(f"Failed to add comment to {record['jira_key']} for issue {issue_id}")

    record["issue_ids"] = list(known_ids | current_ids)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Section 8: Open Case Checker (bidirectional closure)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def check_open_cases(
    cortex: CortexClient, jira: JiraClient, state: dict, config: Config,
) -> dict:
    """Re-check all open synced cases for closures and severity changes."""
    stats = {"cortex_closed": 0, "jira_closed": 0, "severity_updated": 0}

    open_records = {
        cid: rec for cid, rec in state["sync_records"].items()
        if rec["status"] == "open"
    }
    if not open_records:
        return stats

    # Batch-fetch current case state from Cortex
    case_ids = [int(cid) for cid in open_records.keys()]
    cases = cortex.search_cases(
        filters=[{"field": "case_id", "operator": "in", "value": case_ids}]
    )
    case_map = {str(c["case_id"]): c for c in cases}

    for case_id, record in open_records.items():
        case = case_map.get(case_id)

        # Cortex case resolved?
        if case and case.get("status_progress", "").lower() == "resolved":
            record["status"] = "closed"
            record["closed_at"] = datetime.now(timezone.utc).isoformat()
            stats["cortex_closed"] += 1
            demisto.info(f"Case {case_id} resolved in Cortex — marked closed ({record['jira_key']})")
            continue

        # Jira ticket Done?
        try:
            jira_detail = jira.get_issue_detail(record["jira_key"])
            if jira_detail.get("status_category") == "done":
                _close_cortex_case(int(case_id), record["jira_key"], cortex, jira, config)
                record["status"] = "closed"
                record["closed_at"] = datetime.now(timezone.utc).isoformat()
                stats["jira_closed"] += 1
                demisto.info(f"Jira {record['jira_key']} Done — resolved case {case_id}")
                continue
        except Exception:
            demisto.error(f"Failed to check Jira status for {record['jira_key']}: {traceback.format_exc()}")

        # Severity change?
        if case:
            current_severity = case.get("severity", "MEDIUM")
            if current_severity.upper() != record.get("severity", "MEDIUM").upper():
                _sync_severity_change(record, current_severity, jira)
                stats["severity_updated"] += 1

            # New issues on case?
            current_issue_ids = [str(i) for i in case.get("issue_ids", case.get("issues", []))]
            _sync_new_issues(record, current_issue_ids, cortex, jira, state, config)

    demisto.info(
        f"Open case check: {stats['cortex_closed']} Cortex-closed, "
        f"{stats['jira_closed']} Jira-closed, {stats['severity_updated']} severity updates"
    )
    return stats


def _close_cortex_case(
    case_id: int, jira_key: str, cortex: CortexClient, jira: JiraClient, config: Config,
) -> None:
    """Resolve a Cortex case when its Jira ticket reaches Done."""
    # Parse resolution map
    try:
        resolution_map: dict = json.loads(config.resolution_type_map) if config.resolution_type_map else {}
    except (json.JSONDecodeError, TypeError):
        demisto.info("Failed to parse resolution_type_map — using default")
        resolution_map = {}

    default_reason = config.default_resolution_type or "Resolved - Other"
    resolve_reason = default_reason

    # Read Jira changelog to find pre-Done status
    try:
        transitions = jira.get_changelog(jira_key)
        if transitions:
            last_from_status = transitions[-1].get("from_status", "")
            if last_from_status:
                mapped = resolution_map.get(last_from_status)
                if mapped:
                    resolve_reason = mapped
                    demisto.info(f"Closure: '{last_from_status}' -> '{resolve_reason}'")
                else:
                    demisto.info(f"Closure: '{last_from_status}' not in map — using default '{default_reason}'")
    except Exception:
        demisto.error(f"Failed to fetch changelog for {jira_key}: {traceback.format_exc()}")

    # Resolve the Cortex case
    try:
        cortex.update_case(
            case_id=case_id,
            status="Resolved",
            reason=resolve_reason,
            comment=f"Resolved via Jira {jira_key}",
        )
    except Exception:
        demisto.error(f"Failed to resolve Cortex case {case_id}: {traceback.format_exc()}")


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Section 9: Jira -> Cortex Sync
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def sync_jira_to_cortex(
    cortex: CortexClient, jira: JiraClient, state: dict, config: Config,
) -> dict:
    """Find Jira alerts closed since last poll and resolve matching Cortex cases."""
    stats = {"resolved": 0, "issue_closed": 0}

    last_poll_iso = state.get("last_jira_poll_iso", "")
    if not last_poll_iso:
        since = datetime.now(timezone.utc) - timedelta(hours=24)
    else:
        since = datetime.fromisoformat(last_poll_iso) - timedelta(seconds=60)

    now = datetime.now(timezone.utc)
    since_str = since.strftime("%Y-%m-%d %H:%M")

    demisto.info(f"Jira->Cortex: searching for alerts closed since {since_str}")
    try:
        closed_alerts = jira.search_closed_alerts(since_str)
    except Exception:
        demisto.error(f"Failed to search Jira for closed alerts: {traceback.format_exc()}")
        return stats

    for alert in closed_alerts:
        jira_key = alert["key"]

        # Check case records
        for case_id, record in state["sync_records"].items():
            if record["jira_key"] == jira_key and record["status"] == "open":
                try:
                    _close_cortex_case(int(case_id), jira_key, cortex, jira, config)
                    record["status"] = "closed"
                    record["closed_at"] = datetime.now(timezone.utc).isoformat()
                    stats["resolved"] += 1
                except Exception:
                    demisto.error(f"Failed to resolve case {case_id} for {jira_key}: {traceback.format_exc()}")
                break

        # Check issue records
        for issue_id, record in state["issue_sync_records"].items():
            if record["jira_key"] == jira_key and record["status"] == "open":
                record["status"] = "closed"
                record["closed_at"] = datetime.now(timezone.utc).isoformat()
                stats["issue_closed"] += 1
                break

    state["last_jira_poll_iso"] = now.isoformat()
    demisto.info(f"Jira->Cortex: {stats['resolved']} cases resolved, {stats['issue_closed']} issues closed")
    return stats


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Section 10: Standalone Issue Sync
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def sync_issues_to_jira(
    cortex: CortexClient, jira: JiraClient, state: dict, config: Config,
) -> dict:
    """Sync assigned standalone Cortex issues to Jira tickets."""
    stats = {"created": 0, "skipped": 0}

    domain = config.cortex_case_domain.lower()
    filters = [
        {"field": "issue_domain", "operator": "in", "value": [domain.capitalize()]},
    ]
    if config.sync_from_date:
        from_ms = int(datetime.fromisoformat(config.sync_from_date).timestamp() * 1000)
        filters.append({"field": "observation_time", "operator": "gte", "value": from_ms})

    demisto.info(f"Issue sync: searching {domain} domain issues")
    all_issues = cortex.search_issues_filtered(filters=filters)

    # Build exclusion sets
    # Issues already linked to cases (from sync_records issue_ids)
    case_issue_ids: set[str] = set()
    for record in state["sync_records"].values():
        case_issue_ids.update(record.get("issue_ids", []))

    # Issues already synced standalone
    synced_issue_ids = set(state["issue_sync_records"].keys())

    for issue in all_issues:
        issue_id = str(issue.get("id", ""))
        if not issue_id:
            continue

        # Skip if linked to a case
        if issue_id in case_issue_ids:
            continue

        # Skip if already synced
        if issue_id in synced_issue_ids:
            continue

        # Skip if not assigned (we only sync assigned issues)
        assigned_to = issue.get("assigned_to", "")
        if not assigned_to:
            stats["skipped"] += 1
            continue

        # Skip resolved
        status = issue.get("status", {})
        status_progress = status.get("progress", "") if isinstance(status, dict) else str(status)
        if status_progress.upper() == "RESOLVED":
            continue

        # Skip if playbook hasn't completed yet
        pb_state = cortex.get_playbook_state(issue_id)
        if pb_state != "completed":
            demisto.info(f"Issue {issue_id}: playbook not yet completed (state={pb_state}) — deferring")
            continue

        # Build Jira ticket
        severity = issue.get("severity", "MEDIUM")
        name = issue.get("name", issue.get("description", "No description"))
        summary = f"[CORTEX-ISSUE-{issue_id}] {name}"
        description_adf = build_issue_description_adf(issue, config)

        extra_fields: dict = {}
        if config.jira_issue_id_field:
            extra_fields[config.jira_issue_id_field] = str(issue_id)
        if config.jira_xdr_url_field and config.cortex_console_url:
            xdr_url = f"{config.cortex_console_url}/alerts-and-incidents/alerts/{issue_id}"
            extra_fields[config.jira_xdr_url_field] = xdr_url

        # Duplicate detection
        if config.jira_issue_id_field:
            try:
                existing_key = jira.find_ticket_by_field(config.jira_issue_id_field, str(issue_id))
                if existing_key:
                    demisto.info(f"Issue {issue_id} already has Jira ticket {existing_key}")
                    state["issue_sync_records"][issue_id] = {
                        "jira_key": existing_key,
                        "status": "open",
                        "created_at": datetime.now(timezone.utc).isoformat(),
                    }
                    stats["created"] += 1
                    continue
            except Exception:
                demisto.info(f"Duplicate check failed for issue {issue_id} — proceeding")

        # Create ticket
        try:
            jira_key = jira.create_issue(summary, description_adf, severity, extra_fields or None)
        except Exception:
            demisto.error(f"Failed to create Jira issue for Cortex issue {issue_id}: {traceback.format_exc()}")
            continue

        # Auto-assign to the Cortex analyst
        resolve_and_assign(jira, state, jira_key, assigned_to)

        # Record
        state["issue_sync_records"][issue_id] = {
            "jira_key": jira_key,
            "status": "open",
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        stats["created"] += 1
        demisto.info(f"Synced issue {issue_id} -> {jira_key} (assigned: {assigned_to})")

    demisto.info(f"Issue sync: {stats['created']} created, {stats['skipped']} skipped (unassigned)")
    return stats


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Section 11: Retry Queue
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def _enqueue_retry(state: dict, case_id: str, case: dict) -> None:
    """Add a failed case to the retry queue with exponential backoff."""
    # Check if already in queue
    for entry in state["retry_queue"]:
        if str(entry["case_id"]) == str(case_id):
            entry["attempts"] += 1
            backoff_ms = min(60 * 60 * 1000, (2 ** entry["attempts"]) * 60 * 1000)  # cap at 1 hour
            entry["next_retry_ms"] = int(time.time() * 1000) + backoff_ms
            return

    # New entry
    state["retry_queue"].append({
        "case_id": str(case_id),
        "case_json": json.dumps(case, default=str),
        "attempts": 1,
        "next_retry_ms": int(time.time() * 1000) + 120000,  # 2 minutes
    })


def _process_retry_queue(
    cortex: CortexClient, jira: JiraClient, state: dict, config: Config,
) -> int:
    """Process due retry entries. Returns count of successful retries."""
    if not state["retry_queue"]:
        return 0

    now_ms = int(time.time() * 1000)
    succeeded = 0
    remaining: list[dict] = []

    for entry in state["retry_queue"]:
        case_id = str(entry["case_id"])
        attempts = entry["attempts"]

        # Not due yet
        if entry["next_retry_ms"] > now_ms:
            remaining.append(entry)
            continue

        # Abandon after max attempts
        if attempts >= MAX_RETRY_ATTEMPTS:
            demisto.error(f"Retry queue: case {case_id} abandoned after {attempts} attempts")
            continue  # Drop from queue

        # Parse case JSON
        try:
            case = json.loads(entry["case_json"])
        except json.JSONDecodeError:
            demisto.error(f"Retry queue: invalid JSON for case {case_id}, dropping")
            continue

        demisto.info(f"Retry queue: retrying case {case_id} (attempt {attempts + 1}/{MAX_RETRY_ATTEMPTS})")
        result = _handle_case(case, cortex, jira, state, config)

        if result in ("created", "existing"):
            succeeded += 1
            demisto.info(f"Retry queue: case {case_id} succeeded")
            # Don't add back to remaining
        else:
            # Still failing — update entry for next retry
            entry["attempts"] += 1
            backoff_ms = min(60 * 60 * 1000, (2 ** entry["attempts"]) * 60 * 1000)
            entry["next_retry_ms"] = now_ms + backoff_ms
            remaining.append(entry)

    state["retry_queue"] = remaining
    if succeeded:
        demisto.info(f"Retry queue: {succeeded} succeeded, {len(remaining)} remaining")
    return succeeded


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Section 12: Main
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def run_sync() -> str:
    """Execute the full sync cycle. Returns a summary string for the war room."""
    config = Config.from_params()

    errors = config.validate()
    if errors:
        return f"Configuration errors:\n" + "\n".join(f"  - {e}" for e in errors)

    cortex = CortexClient(config)
    jira = JiraClient(config)
    state = get_state()

    results: dict[str, Any] = {}

    # Phase 1: Cortex -> Jira (new cases)
    try:
        results["cortex_to_jira"] = sync_cortex_to_jira(cortex, jira, state, config)
    except Exception:
        demisto.error(f"Cortex->Jira sync failed: {traceback.format_exc()}")
        results["cortex_to_jira"] = {"error": traceback.format_exc()}

    # Phase 2: Check open cases (bidirectional closure, severity sync)
    try:
        results["open_case_check"] = check_open_cases(cortex, jira, state, config)
    except Exception:
        demisto.error(f"Open case check failed: {traceback.format_exc()}")
        results["open_case_check"] = {"error": traceback.format_exc()}

    # Phase 3: Jira -> Cortex (closed alerts)
    try:
        results["jira_to_cortex"] = sync_jira_to_cortex(cortex, jira, state, config)
    except Exception:
        demisto.error(f"Jira->Cortex sync failed: {traceback.format_exc()}")
        results["jira_to_cortex"] = {"error": traceback.format_exc()}

    # Phase 4: Standalone issue sync (if enabled)
    if config.sync_issues:
        try:
            results["issue_sync"] = sync_issues_to_jira(cortex, jira, state, config)
        except Exception:
            demisto.error(f"Issue sync failed: {traceback.format_exc()}")
            results["issue_sync"] = {"error": traceback.format_exc()}
    else:
        results["issue_sync"] = {"skipped": True}

    # Housekeeping: prune old closed records
    pruned = prune_closed_records(state)
    if pruned:
        demisto.info(f"Pruned {pruned} closed records older than {CLOSED_RECORD_TTL_DAYS} days")

    # Persist state
    save_state(state)

    # Summary
    open_cases = sum(1 for r in state["sync_records"].values() if r["status"] == "open")
    open_issues = sum(1 for r in state["issue_sync_records"].values() if r["status"] == "open")
    retry_count = len(state["retry_queue"])

    summary = (
        f"Sync complete. "
        f"Cases: {open_cases} open, {len(state['sync_records'])} total. "
        f"Issues: {open_issues} open, {len(state['issue_sync_records'])} total. "
        f"Retry queue: {retry_count}."
    )
    demisto.info(summary)
    return summary


def test_module() -> str:
    """Verify connectivity to both Cortex and Jira. Called by 'Test' button in XSIAM."""
    config = Config.from_params()

    errors = config.validate()
    if errors:
        return f"Configuration errors: {'; '.join(errors)}"

    # Test Cortex connectivity
    try:
        cortex = CortexClient(config)
        cases = cortex.search_cases(
            filters=[{"field": "status_progress", "operator": "nin", "value": ["Resolved"]}]
        )
        demisto.info(f"Cortex test: found {len(cases)} non-resolved cases")
    except Exception as e:
        return f"Cortex connection failed: {e}"

    # Test Jira connectivity
    try:
        jira = JiraClient(config)
        url = f"{jira.base_url}/rest/api/3/myself"
        resp = jira._request("GET", url)
        resp.raise_for_status()
        user = resp.json()
        demisto.info(f"Jira test: authenticated as {user.get('displayName', 'unknown')}")
    except Exception as e:
        return f"Jira connection failed: {e}"

    return "ok"


def discover_resolutions() -> str:
    """Discover Cortex resolve_reason values and cross-check against Jira workflow statuses."""
    config = Config.from_params()

    errors = config.validate()
    if errors:
        return f"Configuration errors:\n" + "\n".join(f"  - {e}" for e in errors)

    cortex = CortexClient(config)
    jira = JiraClient(config)

    # Step 1: Fetch resolved cases from Cortex to discover valid resolve_reason values
    demisto.info("Discovering resolution types from resolved Cortex cases...")
    cases = cortex.search_cases(
        filters=[{"field": "status_progress", "operator": "in", "value": ["Resolved"]}]
    )

    if not cases:
        return "No resolved cases found in Cortex. Resolve at least one case manually first, then re-run."

    # Extract unique resolve_reason values
    cortex_reasons: set[str] = set()
    for case in cases:
        reason = case.get("resolve_reason", "")
        if reason and reason != "Resolved - Auto Resolve":
            cortex_reasons.add(reason)

    if not cortex_reasons:
        return "Found resolved cases but no resolve_reason values. Cases may have been auto-resolved."

    # Step 2: Derive expected Jira status names (strip "Resolved - " prefix)
    reason_to_status: dict[str, str] = {}
    for reason in sorted(cortex_reasons):
        if reason.startswith("Resolved - "):
            status_name = reason[len("Resolved - "):]
        else:
            status_name = reason
        reason_to_status[reason] = status_name

    # Step 3: Fetch Jira workflow statuses
    demisto.info("Fetching Jira workflow statuses...")
    try:
        jira_statuses = jira.get_project_statuses()
    except Exception:
        jira_statuses = []
        demisto.error(f"Failed to fetch Jira statuses: {traceback.format_exc()}")

    jira_status_lower = {s.lower(): s for s in jira_statuses}

    # Step 4: Cross-check and build map
    resolution_map: dict[str, str] = {}
    matched: list[str] = []
    missing: list[str] = []

    for reason, expected_status in sorted(reason_to_status.items()):
        # Check for exact or case-insensitive match
        if expected_status.lower() in jira_status_lower:
            actual_status = jira_status_lower[expected_status.lower()]
            resolution_map[actual_status] = reason
            matched.append(f"  ✓ {actual_status} → {reason}")
        else:
            missing.append(f"  ✗ {expected_status} — No matching Jira status. Create it in your Jira workflow.")

    # Step 5: Save map to integration context
    state = get_state()
    state["discovered_resolution_map"] = resolution_map
    save_state(state)

    # Step 6: Build output
    lines = [
        f"## Resolution Type Discovery\n",
        f"Found **{len(cortex_reasons)}** resolution types from **{len(cases)}** resolved Cortex cases.\n",
    ]

    if matched:
        lines.append("### Matched (Jira status exists)\n")
        lines.extend(matched)
        lines.append("")

    if missing:
        lines.append("### Missing (create these Jira statuses)\n")
        lines.extend(missing)
        lines.append("")

    if jira_statuses:
        lines.append(f"### Current Jira Workflow Statuses ({config.jira_project_key} / {config.jira_issue_type})\n")
        lines.append(", ".join(jira_statuses))
        lines.append("")

    if resolution_map:
        map_json = json.dumps(resolution_map, indent=2)
        lines.append("### Generated Resolution Map\n")
        lines.append(f"```json\n{map_json}\n```\n")
        lines.append("Copy this JSON into **Settings > Resolution Type Map** to use it.")
        lines.append("")

    if missing:
        lines.append("**Action required:** Create the missing Jira statuses above, then re-run `!cortex-jira-discover-resolutions`.")

    return "\n".join(lines)


def main():
    command = demisto.command()
    demisto.info(f"Command: {command}")

    try:
        if command == "test-module":
            result = test_module()
            demisto.results(result)

        elif command == "fetch-incidents":
            # Cron-triggered sync
            summary = run_sync()
            demisto.info(summary)
            # fetch-incidents doesn't return results to war room
            demisto.incidents([])

        elif command == "cortex-jira-sync":
            # Manual trigger
            summary = run_sync()
            return_results(CommandResults(
                readable_output=summary,
                outputs_prefix="CortexJiraSync",
                outputs={"summary": summary},
            ))

        elif command == "cortex-jira-status":
            # Show current state summary
            state = get_state()
            open_cases = sum(1 for r in state["sync_records"].values() if r["status"] == "open")
            closed_cases = sum(1 for r in state["sync_records"].values() if r["status"] == "closed")
            open_issues = sum(1 for r in state["issue_sync_records"].values() if r["status"] == "open")
            closed_issues = sum(1 for r in state["issue_sync_records"].values() if r["status"] == "closed")

            status = {
                "last_poll_ms": state.get("last_poll_ms", 0),
                "last_jira_poll_iso": state.get("last_jira_poll_iso", ""),
                "open_cases": open_cases,
                "closed_cases": closed_cases,
                "open_issues": open_issues,
                "closed_issues": closed_issues,
                "retry_queue_size": len(state.get("retry_queue", [])),
                "user_cache_size": len(state.get("user_cache", {})),
            }

            md = (
                "## Cortex-Jira Sync Status\n\n"
                f"| Metric | Value |\n"
                f"|--------|-------|\n"
                f"| Last Cortex Poll | {state.get('last_poll_ms', 'never')} |\n"
                f"| Last Jira Poll | {state.get('last_jira_poll_iso', 'never')} |\n"
                f"| Open Cases | {open_cases} |\n"
                f"| Closed Cases | {closed_cases} |\n"
                f"| Open Issues | {open_issues} |\n"
                f"| Closed Issues | {closed_issues} |\n"
                f"| Retry Queue | {len(state.get('retry_queue', []))} |\n"
                f"| Cached Users | {len(state.get('user_cache', {}))} |\n"
            )

            return_results(CommandResults(
                readable_output=md,
                outputs_prefix="CortexJiraSync.Status",
                outputs=status,
            ))

        elif command == "cortex-jira-reset-state":
            # Emergency: clear all state
            save_state({})
            return_results(CommandResults(
                readable_output="Integration state has been reset. Next sync will be a full initial sync.",
            ))

        elif command == "cortex-jira-discover-resolutions":
            result = discover_resolutions()
            return_results(CommandResults(readable_output=result))

        else:
            raise NotImplementedError(f"Unknown command: {command}")

    except Exception as e:
        demisto.error(f"Command {command} failed: {traceback.format_exc()}")
        return_error(f"Failed to execute {command}: {e}")


if __name__ in ("__main__", "__builtin__", "builtins"):
    main()
